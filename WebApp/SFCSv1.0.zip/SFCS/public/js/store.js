let carts = document.getElementsByClassName('fa fa-shopping-cart');

let products = [
	{
		id: 0,
		name: 'White Rice',
		tag: 'whiterice',
		cName: 'meal',
		price: 20000,
		image: 'whiterice',
		inCart: 0
	},
	{
		id: 1,
		name: 'Fried Potato',
		tag: 'friedpotato',
		cName: 'extra',
		price: 20000,
		image: 'friedpotato',
		inCart: 0
	},
	{
		id: 2,
		name: 'France Flan',
		tag: 'franceflan',
		cName: 'dessert',
		price: 25000,
		image: 'franceflan',
		inCart: 0
	},
	{
		id: 3,
		name: 'Fresh Milk',
		tag: 'freshmilk',
		cName: 'drink',
		price: 20000,
		image: 'freshmilk',
		inCart: 0
	},
	{
		id: 4,
		name: 'Coffee',
		tag: 'coffee',
		cName: 'drink',
		price: 30000,
		image: 'coffee',
		inCart: 0
	},
	{
		id: 5,
		name: 'Green tea',
		tag: 'greentea',
		cName: 'drink',
		price: 10000,
		image: 'greentea',
		inCart: 0
	},
	{
		id: 6,
		name: 'Bubble milk tea',
		tag: 'bubblemilktea',
		cName: 'drink',
		price: 45000,
		image: 'bubblemilktea',
		inCart: 0
	},
	{
		id: 7,
		name: 'Hamburger',
		tag: 'hamburger',
		cName: 'fastfood',
		price: 30000,
		image: 'hamburger',
		inCart: 0
	}
];

for (let i = 0; i < carts.length; i++){
	carts[i].addEventListener('click', () =>{
		cartNumbers(products[i]);
		totalCost(products[i]);
	})
}

function onLoadCartNumbers(){
	let productNumbers = localStorage.getItem('cartNumbers');
	
	if (productNumbers){
		document.getElementById("cartNumber").textContent = productNumbers;
	}
}

function cartNumbers(product){
	let productNumbers = localStorage.getItem('cartNumbers');
	productNumbers = parseInt(productNumbers);
	if(productNumbers) {
		localStorage.setItem('cartNumbers', productNumbers + 1);
	}
	else{
		localStorage.setItem('cartNumbers', 1);
	}
	onLoadCartNumbers()
	setItems(product);
}

function setItems(product){
	let cartItems = localStorage.getItem('productsInCart');
	cartItems = JSON.parse(cartItems);
	
	if(cartItems != null){
		if (cartItems[product.tag] == undefined){
			cartItems = {
				...cartItems,
				[product.tag]: product
			}
		}
		cartItems[product.tag].inCart += 1;
	}
	else{
		product.inCart = 1;
		cartItems = {
			[product.tag]: product
		}
	}
	
	localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(product){
	let cartCost = localStorage.getItem('totalCost');
	if (cartCost != null){
		cartCost = parseInt(cartCost);
		localStorage.setItem("totalCost", cartCost + product.price);
	} else{
		localStorage.setItem("totalCost", product.price);
	}
}

function displayCart(){
	let cartItems = localStorage.getItem("productsInCart");
	cartItems = JSON.parse(cartItems);
	let tBody = document.getElementById('Customdata');
	let cartCost = localStorage.getItem('totalCost');
	let checkOut = document.getElementById('checkout');
	if (cartItems){
		tBody.innerHTML = '';
		Object.values(cartItems).map(item => {
			tBody.innerHTML += `<tr>
                                    <td class="shoping__cart__item">
                                        <img src="img/product/${item.image}.jpg" alt="" width=10%>
                                        <h5>${item.name}</h5>
                                    </td>
                                    <td class="shoping__cart__price">
                                       ${item.price/1000}.000₫
                                    </td>
                                    <td class="shoping__cart__quantity">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <input type="text" value="${item.inCart}">
                                            </div>
                                        </div>
                                    </td>
                                    <td class="shoping__cart__total">
                                        ${item.price * item.inCart / 1000}.000₫
                                    </td>
                                    <td class="shoping__cart__item__close">
                                        <span class="icon_close" type="button"></span>
                                    </td>
                                </tr>`
		});
		checkOut.innerHTML = `
		<h5>Cart Total</h5>
                        <ul>
                            <li>Subtotal <span>${cartCost/1000}.000₫</span></li>
                            <li>Total <span>${cartCost/1000}.000₫</span></li>
                        </ul>
                        <a href="#" class="primary-btn">PROCEED TO CHECKOUT</a>`
	}
}

onLoadCartNumbers();
displayCart();